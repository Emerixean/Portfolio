package lab5d;


public class Circle extends Shape {
    private static double radius;
    private double area;

    


public Circle (int x , int y , int z, double r){
    super(x,y,z);
    radius = r;

}

public static double getRadius(){
    return radius;}

public double getArea(){
    return area;}



        @Override
        public double area(){
    return area = (Math.PI) * (Math.pow(radius, 2));}  

    @Override
    public String toString(){
    return "("+ super.getX()+","+super.getY()+","+super.getZ()+ "): "+"( " + area() + " )";}
}
