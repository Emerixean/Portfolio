
package lab5d;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class Lab5D extends JPanel {
    
    private final int MAX_LAYER = 10;
    
    private ArrayList<Shape> shapes;
    
    /* CONSTRUCTOR */
    
    public Lab5D() {
        
        super();
        
        this.setBackground(Color.decode("#00BFFF")); // Deep Sky Blue

        shapes = new ArrayList<>();
        
        /* Create Shapes */
        for (int i = 0; i < 30; ++i){
        int choice = (int)((Math.random()*3)+1);
        int x1 = (int)((Math.random()*500)+1);
        int y1 = (int)((Math.random()*500)+1);
        int z1 = (int)(Math.random()*10);
        int rad = (int)((Math.random()*(100-10))+10);
        int len = (int)((Math.random()*(100-10))+10);
        int wid = (int)((Math.random()*(100-10))+10);
        int base = (int)((Math.random()*(100-10))+10);
        int height = (int)((Math.random()*(100-10))+10);
        
        if (choice == 1){
            shapes.add(new Rectangle(x1,y1,z1,len,wid));}
        else if (choice == 2){
            shapes.add(new Circle(x1,y1,z1,rad));}
        else if (choice ==3){
            shapes.add(new Triangle(x1,y1,z1,base,height));}
        }
            
       /* shapes.add(new Rectangle(100, 100, 0, 100, 100));
        shapes.add(new Circle(400, 100, 1, 50));
        shapes.add(new Triangle(250, 350, 2, 100, 100));
        */
        
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g);

        /* Iterate through Layers 1 through 10 */
        
        for (int i = 0; i < MAX_LAYER; ++i) {

            /* Iterate through Shape collection */
        
            for (Shape s : shapes) {

                /* Get X and Y coordinates */
                
                int x = s.getX();
                int y = s.getY();

                /* Check Layer */
                
                if (s.getZ() == i) {

                    /* RECTANGLE */

                    if (s instanceof Rectangle) {

                        g.setColor(Color.decode("#B22222")); // Firebrick Red
                        
                        // INSERT YOUR CODE HERE
                        int l = (int)Rectangle.getLength();
                        int w = (int)Rectangle.getWidth();
                        
                        g.fillRect(x - (l/2), y - (w / 2), l, w);

                    }

                    /* CIRCLE */

                    else if (s instanceof Circle) {

                        g.setColor(Color.YELLOW); // Yellow

                        // INSERT YOUR CODE HERE
                        int r = (int) Circle.getRadius();
                        g.fillOval(x - r,y - r,(int)(r * 2),(int)(r * 2));
                    }

                    /* TRIANGLE */

                    else if (s instanceof Triangle) {

                        g.setColor(Color.decode("#228B22")); // Forest Green
                        
                        // INSERT YOUR CODE HERE
                        int b = (int)Triangle.getBase();
                        int h = (int)Triangle.getHeight();
                        int xpoints[] = {x+(b/2),x-(b/2),x};
                        int ypoints[] = {y+(h/2),y+(h/2),y-(h/2)};
                        g.fillPolygon(xpoints, ypoints, 3);
                    }

                    }
                    
                    /* Tag shape with area */

                    g.setColor(Color.ORANGE);
                    g.drawString(Integer.toString((int)s.area()), x, y);
                    
                } // end layer if

            } // end shapes loop
            
        } // end layer loop
        
    } // end paintComponent()

