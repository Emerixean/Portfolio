package lab5d;

/**
 *
 * @author corda
 */
public class Point {
    private int x;
    private int y;
    private int z;
    
    public Point(int x, int y, int z){
        setX(x);
        setY(y);
        setZ(z);
    }
    
    public int getX(){
    return x;}
    
    public int getY(){
        return y;}

    public int getZ(){
        return z;}
    
    public void setX(int x) {
        if (x < 0)
            this.x = 0;
        else if (x > 500)
            this.x = 500;
        else
            this.x = x;}
        
    
    public void setY(int y) {
        if (y < 0)
            this.y = 0;
        else if (y > 500)
            this.y = 500;
        else
            this.y = y;}
    
    public void setZ(int z){
        this.z = z;
    }
}
