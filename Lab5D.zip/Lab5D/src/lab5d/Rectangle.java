package lab5d;

/**
 *
 * @author corda
 */
public class Rectangle extends Shape{
    private static double length;
    private static double width;
    private double area;

    

public Rectangle (int x, int y, int z, double l, double w){
    super(x,y,z);
    length= l;
    width = w;
}

public static double getLength(){
    return length;}

public static double getWidth(){
    return width;}

public double getArea(){
    return area;}



    @Override
    public double area(){
    return area = length * width ;}  

       @Override
       public String toString(){
    return "("+ super.getX()+","+super.getY()+","+super.getZ()+ "): "+"[ " + area() + " ]" ;}
}
