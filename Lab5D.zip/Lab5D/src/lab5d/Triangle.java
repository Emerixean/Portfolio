package lab5d;

public class Triangle extends Shape{
    private static double base;
    private static double height;
    private double area;

    

public Triangle (int x, int y , int z, double b, double h){
    super(x,y,z);
    base = b;
    height = h;
}

public static double getBase(){
    return base;}

public static double getHeight(){
    return height;}

public double getArea(){
    return area;}


        @Override
        public double area(){
    return area = 0.5 * (base * height);}  

    @Override
    public String toString(){
    return "("+ super.getX()+","+super.getY()+","+super.getZ()+ "): "+"/ " + area() + " \\" ;}
}
